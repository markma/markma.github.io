---
title: 
date: 2016/8/9 9:35:54 
comments: true
---

----------

>This blog is based on [Hexo](https://hexo.io/ "hexo") and a hexo theme named [spkf](https://github.com/luuman/hexo-theme-spfk). Thans for their selfless contribution!

Me:
我是一名机械工程的硕士，然而编程的魅力深深的吸引着我以至于无法自拔。目前主要在学习C++和python。这个博客空间记录着我学习的点点滴滴，同时也希望能于各位爱好者各位coder互相交流，互相学习。


![Maile to me](http://i.imgur.com/AgDoIfa.png):<ma-mark@outlook.com>
----------
![QQ to me](http://i.imgur.com/vPCiIgT.png):954373276
----------


